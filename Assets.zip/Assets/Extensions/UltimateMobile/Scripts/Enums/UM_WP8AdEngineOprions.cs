﻿using UnityEngine;
using System.Collections;

public enum UM_WP8AdEngineOprions  {
	GoogleMobileAd 
}
