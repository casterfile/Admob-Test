﻿using UnityEngine;
using System.Collections;

public enum UM_ConnectionState  {

	UNDEFINED,
	CONNECTING,
	CONNECTED,
	DISCONNECTED
}
