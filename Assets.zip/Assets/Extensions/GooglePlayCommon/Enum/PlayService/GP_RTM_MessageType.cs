﻿using UnityEngine;
using System.Collections;

public enum GP_RTM_MessageType  {

	Reliable = 0,
	Unreliable = 1

}
