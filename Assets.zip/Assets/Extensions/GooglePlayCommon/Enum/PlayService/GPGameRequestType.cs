﻿using UnityEngine;
using System.Collections;

public enum GPGameRequestType  {

	TYPE_GIFT = 1,
	TYPE_WISH = 2
}
