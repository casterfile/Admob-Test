////////////////////////////////////////////////////////////////////////////////
//  
// @module Common Android Native Lib
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////


 

using System;


public static class GoogleCloudSlot {

	public const int SLOT_0 = 0;
	public const int SLOT_1 = 1;
	public const int SLOT_2 = 2;
	public const int SLOT_3 = 3;
}


