﻿using UnityEngine;
using System.Collections;

public class GP_SnapshotMeta  {

	public string Title;
	public string Description;
	public string CoverImageUrl;


	public long LastModifiedTimestamp;
	public long TotalPlayedTime;



}
