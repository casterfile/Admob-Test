using UnityEngine;
using System.Collections;

public class GP_Invite  {

	public string Id;
	public long CreationTimestamp;
	public GP_InvitationType InvitationType;
	public int Variant;
	public GP_Participant Participant;
}
