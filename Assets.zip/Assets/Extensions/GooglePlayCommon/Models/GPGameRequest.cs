﻿using UnityEngine;
using System.Collections;

public class GPGameRequest  {


	public string id;
	public string playload;


	public long expirationTimestamp;
	public long creationTimestamp;


	public string sender;
	public GPGameRequestType type;

}
