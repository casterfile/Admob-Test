﻿using UnityEngine;
using System.Collections;

public class GP_AchievementResult : GooglePlayResult {

	public string achievementId = "";

	public GP_AchievementResult(string code):base(code) {

	}
}
