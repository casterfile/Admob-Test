﻿using UnityEngine;
using System.Collections;

public enum AN_Bool  {
	Yes,
	No
}
