﻿using UnityEngine;
using System.Collections;

public enum AndroidCameraImageFormat {
	JPG = 0,
	PNG = 1
}
