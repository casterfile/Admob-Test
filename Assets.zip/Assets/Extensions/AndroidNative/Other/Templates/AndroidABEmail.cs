﻿using UnityEngine;
using System.Collections;

public class AndroidABEmail {

	public string email, emailType;
}
