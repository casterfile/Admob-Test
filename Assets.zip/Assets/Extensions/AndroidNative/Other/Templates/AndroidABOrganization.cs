﻿using UnityEngine;
using System.Collections;

public class AndroidABOrganization {

	public string name, title;
}
