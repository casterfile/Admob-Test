﻿using UnityEngine;
using System.Collections;

public class PackageAppInfo : MonoBehaviour {

	public string versionName;
	public string versionCode;
	public string packageName;
	public string sharedUserId;
	public string sharedUserLabel;

	public long lastUpdateTime;
}
