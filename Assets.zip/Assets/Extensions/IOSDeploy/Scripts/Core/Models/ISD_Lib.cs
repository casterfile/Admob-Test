﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class ISD_Lib  {

	//Editor Use Only
	public bool IsOpen = true;
	
	public string Name;
	public bool IsOptional;
	
}
