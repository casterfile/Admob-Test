﻿using UnityEngine;
using System.Collections;

public enum ISN_InAppType  {
	Consumable,
	NonConsumable
}
