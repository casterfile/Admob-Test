﻿using UnityEngine;
using System.Collections;

public enum  ISN_Bool  {
	Yes,
	No
}
