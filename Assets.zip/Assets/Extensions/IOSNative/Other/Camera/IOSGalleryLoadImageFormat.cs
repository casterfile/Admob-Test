﻿using UnityEngine;
using System.Collections;

public enum IOSGalleryLoadImageFormat  {

	PNG = 0,
	JPEG = 1
}
