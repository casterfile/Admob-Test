﻿using UnityEngine;
using System.Collections;

public enum ISN_ImageSource  {
	Library = 0,
	Album = 1,
	Camera = 2
}
