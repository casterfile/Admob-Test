﻿using UnityEngine;
using System.Collections;

public enum MP_MusicRepeatMode  {
	Default = 0,
	None = 1,
	One = 2,
	All = 3
}
