﻿using UnityEngine;
using System.Collections;

public enum GK_PlayerConnectionState  {
	Unknown = 0,
	Connected = 1,
	Disconnected = 2
}
