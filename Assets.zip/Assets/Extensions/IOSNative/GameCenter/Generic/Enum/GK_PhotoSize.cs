﻿using UnityEngine;
using System.Collections;

public enum GK_PhotoSize {
	GKPhotoSizeSmall = 0,
	GKPhotoSizeNormal = 1
}
