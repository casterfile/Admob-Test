﻿using UnityEngine;
using System.Collections;

public enum WP8PurchaseCodes  {
	SUCCSES = 0,
	CANCELED = 1,
	ERROR = 2,
	PURCHASED = 3
}
