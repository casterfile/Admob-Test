﻿using UnityEngine;
using System.Collections;

public enum WP8PurchaseProductType {
	Consumable,
	Durable
}
