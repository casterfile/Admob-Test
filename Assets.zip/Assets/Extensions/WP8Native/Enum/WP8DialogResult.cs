﻿using UnityEngine;
using System.Collections;

public enum WP8DialogResult {
	YES,
	NO,
	RATED,
	REMIND,
	DECLINED
	
}
