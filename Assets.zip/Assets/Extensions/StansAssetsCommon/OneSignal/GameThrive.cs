﻿using System;

[Obsolete("GameThrive is decorated and will be removed in future releases. Please rename GameThrive to OneSignal in your code and your AndroidManifest.xml if your app is for Android.")]
public class GameThrive : OneSignal {
}